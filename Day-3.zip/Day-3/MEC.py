#!/usr/bin/env python
# coding: utf-8

# In[1]:


# -----> Numpy
# Numpy is a fundamental package used for Scientific 
# computation in pytonh.
# Numpy array can hold only Homogenous elements.
# Numpy arrays are mutable.
# Numpy arrays are faster then list coz it was 
# created based on C langauge.
# The elements in array can be stores in contegious 
# memory location.


# In[2]:


l1 = [1,2,3,4,5,6]


# In[3]:


l1


# In[4]:


import numpy


# In[5]:


arr = numpy.array(l1)


# In[22]:


arr


# In[23]:


type(arr)


# In[24]:


print(arr)


# In[26]:


print(arr*2)

'''
for val in arr:
   print(val*2, end=" ")

arr*2
or
arr+3
'''


# In[17]:


# int8, int16, int32, int64, float, float16, float32, float64,
# complex64, complex128


# In[16]:


# To find the dataype of numpy array
arr.dtype


# In[20]:


import numpy as np
t1 = (1,2,3,4,5)
np.array(t1)
t1


# In[27]:


s1 = 'hello'
ans = np.array(s1)
ans


# In[32]:


# To add element inside array
# append()
# new_arr = np.append(arr, 89)
# new_arr

# to add multiple elements
# new_arr = np.append(arr, [45, 67, 100])
# new_arr


# In[34]:


# n1 = np.insert(arr, 2, 100)
# n1

# Multiple element insert
# n2 = np.insert(arr, 3, (345, 678, 890))
# print(n2)


# In[38]:


# delete an element from array
# nr = np.delete(arr, np.where(arr==4))
# print(nr)

# Delete collection of elements
# nr = np.setdiff1d(arr, [1,2,3])
# print(nr)

# Delete element based on index position
# nr = np.delete(arr, [0, 2]) # 0, 2 is index position values
# nr


# In[44]:


# To delete multiple elements in the list based 
# on index position

# l1 = ["hello", "world", "hey","there"]
# index = (0, 1)
# for i in range(0, len(l1)):
#     if i in index:
#         l1.pop(i)
#         l1.insert(i, None)
# for val in l1:
#     if val !=None:
#         print(val, end=" ")


# In[45]:


arr


# In[49]:


# filter all element which is below 5
print(arr<5)


# In[50]:


print(arr[arr<5])


# In[51]:


# Display elements between 2 and 6
arr[(arr>2) & (arr<6)]


# In[63]:


# replace all the element which is equal to 3

# s1 = "hello"
# print(s1.replace('l', "z"))

# l1 = [1,2,3,4]
# l1[2] = 45
# print(l1)

# ----> in array
# element = 45
# arr[arr==3]=45
# arr


# In[65]:


npz = np.zeros(3)
print(npz)


# In[66]:


npz.dtype


# In[68]:


# typecase float to int
npz = np.zeros(3, dtype=int)
print(npz, npz.dtype)


# In[70]:


npz = np.zeros(3, dtype="int64")
print(npz.dtype)


# In[86]:


# number_of_elements = 5
# l1=[]
# for i in range(number_of_elements):
#     l1.append(1)
# print(l1)

# npo = np.ones(4) # 4 is number of 1, to be added in array
# npo


# In[92]:


# nested array
my_mat = [[1,2,3], [4,5,6], [7,8,9]]
np1 = np.array(my_mat)
print(np1)


# In[88]:


# arange()
# np.arange(0, 10)


# In[89]:


np.zeros((3, 4))


# In[90]:


# linspace() --> used to fill the array with eqully seperated
# values between the range of nummber
np.linspace(1,10)


# In[91]:


np.linspace(1, 10, 5)


# In[94]:


np1


# In[97]:


# l1 = [1,2,3,4,5,6]
# print(l1[3:])

# Slicing in multidimenstional array
# np1[rows, columns]
np1[0:2] # to diaplay first two rows 


# In[98]:


np1[:, 0:2]


# In[99]:


np1


# In[101]:


np1[1:, 1:]


# In[102]:


# pandas
# Pandas is a open sourec libreary that provides
# high performance data manipulation in python.

# The name pandas came from Panel data, which means Econometrics
# Multidimentional data.
# Data analysis requires lots of process like clening, restructuring,
# merging etc.. In order to do these operation in faster and simpler
# manner, pandas is used


# In[103]:


# Pandas series
# Its is a one dimenstion labelled array. Its a primary
# buildinhg block for a dataframe, making up 
# its rows and columns


# In[104]:


import pandas as pd
labels = ['a', 'b', 'c']
pd.Series(data=labels)


# In[108]:


my_data = ["fisrt alpha", "second alpha", "thirs alpha"]
ans = pd.Series(data=my_data, index=labels, name="Alphabets")


# In[109]:


ans


# In[110]:


ser1 = pd.Series([1,2,3,4,5], ["USA", "India", "england", "canada", "China"])


# In[111]:


ser1


# In[112]:


ser1["england"]


# In[113]:


ser1[2] # 2 is an index value


# In[114]:


ser1[1:4]


# In[115]:


# --> to add 2 series
ser1


# In[116]:


ser2 = pd.Series([5,6,7], ["USA", "India", "canada"])
ser2


# In[117]:


ser1+ser2


# In[119]:


# DataFrame
from numpy.random import randn


# In[120]:


# Syntax of datframe --> pd.DataFrame(elemnts, rows, columns)


# In[121]:


randn(1, 10)


# In[122]:


df = pd.DataFrame(randn(5, 4))


# In[123]:


df


# In[125]:


df = pd.DataFrame(randn(5, 4), ["A", "B", "C", "D", "E"], ["W","X", "Y","Z"])


# In[126]:


df


# In[131]:


# To convert a dictionary to a dataframe
# d = {"col1":[1,2], "col2":[3, 4]}
# df = pd.DataFrame(d, ["row1", "row2"])
# df


# # Day-3

# In[1]:


# datacleaning and data processing
import pandas as pd


# In[120]:


df =pd.read_csv(r"Kaagle_Salaries.csv")
# r"C:\Users\Siddharth\OneDrive\Documents\Desktop\Kaagle_Salaries.csv"


# In[121]:


df


# In[5]:


# To select only specifies number of rows
df.head(10)


# In[6]:


# To get the complete information about dataframe
df.info()


# In[7]:


# 1.) To find the average basepay
# To access a specific column in a dataframe
df["BasePay"]


# In[11]:


# To get multiple columns in a dataframe
df[["BasePay", "EmployeeName"]]


# In[12]:


# To find the average of Basepay column
df["BasePay"].mean()


# In[14]:


df["BasePay"]


# In[15]:


df["BasePay"]=="Not Provided"


# In[17]:


# To get the complete row details of a specific value
df[df["BasePay"]=="Not Provided"]


# In[18]:


# To find the dataype of values in a cloumn
df["BasePay"].dtype


# In[21]:


df["BasePay"] = df["BasePay"].str.replace("Not Provided", "0.0")


# In[23]:


df[df["BasePay"]=="Not Provided"]


# In[25]:


df["BasePay"] = df["BasePay"].astype(float)


# In[26]:


df["BasePay"].dtype


# In[27]:


# To delete all nulll values
df["BasePay"].dropna()


# In[28]:


df["BasePay"].mean()


# In[30]:


# To Acess dataframe based on row
df.loc[3]


# In[32]:


# based on index
df.iloc[0]


# In[33]:


df


# In[41]:


# To get Total pay of a specific employee
df[df["EmployeeName"]=="NATHANIEL FORD"]["TotalPay"]


# In[43]:


df["TotalPayBenefits"]


# In[44]:


df["TotalPayBenefits"].max()


# In[46]:


df[df["TotalPayBenefits"]==df["TotalPayBenefits"].max()]


# In[47]:


df[df["TotalPayBenefits"]==df["TotalPayBenefits"].max()]["EmployeeName"]


# In[48]:


df[df["TotalPayBenefits"]==df["TotalPayBenefits"].min()]


# In[49]:


df[df["TotalPayBenefits"]==df["TotalPayBenefits"].min()]["EmployeeName"]


# In[52]:


# To find hoe many job titles are present
df["JobTitle"].unique()


# In[53]:


df["JobTitle"].nunique()


# In[56]:


# To find the top 5 jobtitles
df['JobTitle'].value_counts().head(5)


# In[57]:


# Machine learning Algorithm


# In[58]:


# -----> Logistic algorithm
# It is a method of classification
# Eg: binary classifictaion

# 1.) Spam mail or not
# 2.) Going to get loan or not
# 3.)if a specific perosn has  disease or not

# It can take any value as the output between 0 and 1
# Graph will be like a curve

# Logistic regression is used to predict the catagorical 
# dependent variable using given set of independent 
# varibales


# In[59]:


# Eg:1
from sklearn.datasets import load_breast_cancer


# In[60]:


data =load_breast_cancer()


# In[61]:


data


# In[62]:


data1 = load_breast_cancer(as_frame=True)


# In[63]:


data1


# In[65]:


from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score


# In[70]:


X, y = load_breast_cancer(return_X_y = True)


# In[71]:


X


# In[72]:


y


# In[74]:


len(X)


# In[75]:


len(y)


# In[76]:


X_train, X_test, y_train, y_test = train_test_split(X, y, train_size = 0.2)


# In[77]:


X_train.shape


# In[78]:


X_test.shape


# In[79]:


clf =LogisticRegression()


# In[80]:


clf.fit(X_train, y_train)


# In[81]:


# To predict the output
y_pred = clf.predict(X_test)


# In[82]:


y_pred


# In[83]:


acc =accuracy_score(y_test, y_pred)


# In[84]:


acc


# In[85]:


acc*100


# In[87]:


import numpy as np
data = np.array([4,np.nan, 5, np.nan, 10, 11, 23, np.nan])


# In[89]:


data


# In[90]:


new_data = data[~np.isnan(data)]


# In[91]:


new_data


# In[96]:


from numpy.random import randn


# In[97]:


df1 = pd.DataFrame(randn(5, 4), ["A", "B", "C", "D", "E"], ['w','x', 'y', 'z'])


# In[98]:


df1


# In[106]:


df1["w"] = df1['w'].astype(int)


# In[107]:


df1['w']


# In[102]:


df1.loc["A"]


# In[103]:


df1.iloc[1]


# In[122]:


df["BasePay"].isna().sum()


# In[124]:


df.fillna(value="0.0")


# In[125]:


# df["BasePay"]


# In[126]:


df["BasePay"] = df["BasePay"].astype(int)


# In[127]:


pip list


# In[128]:


# Titanic dataset
import pandas as pd
import numpy as np


# In[129]:


train = pd.read_csv("titanic_train.csv")


# In[130]:


train.head()


# In[131]:


# to find the null values in ds
train.isnull()


# In[133]:


import matplotlib.pyplot as plt
import seaborn as sns
get_ipython().run_line_magic('matplotlib', 'inline')


# In[135]:


sns.heatmap(train.isnull(), cmap="viridis")


# In[140]:


sns.distplot(train["Age"].dropna(), bins=80, kde=False)


# In[142]:


sns.countplot(x="Survived", data=train)


# In[143]:


sns.countplot(x="Survived", data=train, hue="Sex")


# In[144]:


sns.countplot(x="Survived", data=train, hue="Pclass")


# In[ ]:




